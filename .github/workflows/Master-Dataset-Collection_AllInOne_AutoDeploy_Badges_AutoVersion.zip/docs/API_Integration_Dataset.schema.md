# API Integration Dataset

Endpoints and auth methods.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, service, auth_method

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `auth_method` | `string` | yes | enum: API Key, OAuth 2.0, JWT Bearer, HMAC |
| `category` | `string` | yes |  |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `service` | `string` | yes |  |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |