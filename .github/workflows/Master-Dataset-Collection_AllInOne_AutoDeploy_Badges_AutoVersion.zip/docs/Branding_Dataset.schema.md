# Branding Dataset

Brand colors, typography.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, brand_name, colors

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `brand_name` | `string` | yes |  |
| `category` | `string` | yes |  |
| `colors` | `object` | yes |  |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |