# Voice Command (AR) Dataset

Recognized phrases, intents, locales.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, phrase, intent, locale

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `category` | `string` | yes |  |
| `confidence_threshold` | `number` | no | range: 0–1 |
| `id` | `string` | yes |  |
| `intent` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `locale` | `string` | yes | pattern: `^[a-z]{2}-[A-Z]{2}$` |
| `phrase` | `string` | yes |  |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |