import sys
from pathlib import Path
import pandas as pd
ROOT = Path('.'); CSV_DIR = ROOT/'extras'/'csv'; PARQUET_DIR = ROOT/'extras'/'parquet'
PARQUET_DIR.mkdir(parents=True, exist_ok=True)
built=0
for csv in CSV_DIR.glob('*.csv'):
    try:
        df=pd.read_csv(csv); out=PARQUET_DIR/(csv.stem+'.parquet'); df.to_parquet(out,index=False); print('Built', out); built+=1
    except Exception as e:
        print('Failed', csv.name, e, file=sys.stderr)
print('Parquet build complete:', built)
