# Host Approval Logic Dataset

Queue rules.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, priority, escalation

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `category` | `string` | yes |  |
| `escalation` | `string` | yes | enum: notify_admin, suspend_user, log_only, auto_approve |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `priority` | `integer` | yes | range: 1–5 |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |