import json, sys, re
from pathlib import Path
from datetime import datetime
from jsonschema import Draft202012Validator
import pandas as pd

ROOT = Path("."); REQ=["id","category","tags","last_updated"]; MIN=200

TAG_RULES = {
  "Product_Label_Dataset.json": {"allowed": {"ingredients","directions","compliance","Bold & Buff"}},
  "Marketing_Assets_Dataset.json": {"allowed": {"flyer","ad","caption"}},
  "UI_Asset_Map.json": {"allowed": {"ui","assets"}},
}

def isoish(x):
    try: datetime.fromisoformat(str(x)); return True
    except Exception: return False

def load(p): return json.loads(p.read_text(encoding="utf-8"))

def validate_against_schema(file_name: str, arr):
    schema_path = Path('schemas') / (Path(file_name).stem + '.schema.json')
    if not schema_path.exists(): return []
    schema = json.loads(schema_path.read_text(encoding='utf-8'))
    v = Draft202012Validator(schema)
    errors = [f"{file_name}: schema error -> {e.message}" for e in v.iter_errors(arr)]
    return errors

def hygiene_checks(file_name: str, arr):
    errs=[]; rule = TAG_RULES.get(file_name)
    for i,row in enumerate(arr):
        if "tags" in row:
            if not isinstance(row["tags"], list):
                errs.append(f"{file_name} row {i}: tags not list"); continue
            if rule and "allowed" in rule:
                bad=[t for t in row["tags"] if t not in rule["allowed"]]
                if bad:
                    errs.append(f"{file_name} row {i}: disallowed tags -> {bad}")
        # URL/path patterns
        for k,v in list(row.items()):
            if isinstance(v,str) and k.lower().endswith("url") and not re.match(r"^https?://", v):
                errs.append(f"{file_name} row {i}: field `{k}` must start with http(s)://")
        if file_name=="Website_Content_Dataset.json" and isinstance(row.get("path"), str) and not row["path"].startswith("/"):
            errs.append(f"{file_name} row {i}: path must start with /")
        if file_name=="UI_Asset_Map.json" and isinstance(row.get("path"), str) and not row["path"].startswith("assets/"):
            errs.append(f"{file_name} row {i}: path must start with assets/")
    return errs

def main():
    idx = load(ROOT/"index.json")
    expected = {it["file"]: it.get("entries") for it in idx if isinstance(it, dict) and "file" in it}
    errors=[]; files=0; total=0
    for p in ROOT.glob("*.json"):
        if p.name=="index.json": continue
        files+=1
        arr=load(p)
        if not isinstance(arr,list): errors.append(f"{p.name}: not a list"); continue
        total+=len(arr)
        if len(arr)<MIN: errors.append(f"{p.name}: only {len(arr)} entries (<{MIN})")
        for i,row in enumerate(arr):
            for f in REQ:
                if f not in row: errors.append(f"{p.name} row {i}: missing {f}")
            if "last_updated" in row and not isoish(row["last_updated"]): errors.append(f"{p.name} row {i}: last_updated not ISO-like")
        try: pd.DataFrame(arr[:100]).to_csv(index=False)
        except Exception as e: errors.append(f"{p.name}: csv roundtrip failed: {e}")
        errors.extend(validate_against_schema(p.name, arr))
        errors.extend(hygiene_checks(p.name, arr))
        exp=expected.get(p.name)
        if isinstance(exp,int) and exp!=len(arr): errors.append(f"{p.name}: index says {exp}, file has {len(arr)}")
    print(f"Validated {files} files; {total} total entries.")
    if errors:
        print("Errors:"); [print("- "+e) for e in errors]; sys.exit(2)
    print("All datasets valid.")
if __name__=="__main__": main()
