# Product Label Dataset

Ingredients, directions, compliance.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, brand, product_name, ingredients, directions

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `brand` | `string` | yes |  |
| `category` | `string` | yes |  |
| `directions` | `string` | yes |  |
| `id` | `string` | yes |  |
| `ingredients` | `array` | yes | items: string |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `product_name` | `string` | yes |  |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |