[![Pages](https://github.com/NextLayerLabs/Master-Dataset-Collection/actions/workflows/pages.yml/badge.svg)](https://github.com/NextLayerLabs/Master-Dataset-Collection/actions/workflows/pages.yml)
[![Validate](https://github.com/NextLayerLabs/Master-Dataset-Collection/actions/workflows/bootstrap.yml/badge.svg)](https://github.com/NextLayerLabs/Master-Dataset-Collection/actions/workflows/bootstrap.yml)
[![Auto Version](https://github.com/NextLayerLabs/Master-Dataset-Collection/actions/workflows/auto-version.yml/badge.svg)](https://github.com/NextLayerLabs/Master-Dataset-Collection/actions/workflows/auto-version.yml)

**Docs:** https://NextLayerLabs.github.io/Master-Dataset-Collection/

# Master Dataset Collection

This repo contains 30 JSON datasets (≥200 entries each), strict per‑dataset JSON Schemas, CSV/JSONL exports,
docs generated from schemas (MkDocs), and GitHub Actions for validation, releases, and Pages.

[![pages-build-deployment](https://github.com/NextLayerLabs/Master-Dataset-Collection/actions/workflows/gh-pages.yml/badge.svg)](https://github.com/NextLayerLabs/Master-Dataset-Collection/actions/workflows/gh-pages.yml)

**Docs site (after first push):** https://NextLayerLabs.github.io/Master-Dataset-Collection/

## Quickstart

```bash
make install
make validate
make build-parquet
make serve-docs
```
