# Story Bible Dataset

Story_Bible_Dataset schema

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `category` | `string` | yes |  |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |