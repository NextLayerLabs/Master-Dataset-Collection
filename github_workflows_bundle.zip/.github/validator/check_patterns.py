#!/usr/bin/env python3
"""
Validates that JSON fields named 'url' and 'path' match configured regexes in
.github/validator/path_patterns.json. If the config file is missing or empty, exit successfully.
"""
import os, sys, json, pathlib, re

cfg_path = pathlib.Path(".github/validator/path_patterns.json")
if not cfg_path.exists():
    print("No path_patterns.json found; skipping pattern checks.")
    sys.exit(0)

try:
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
except Exception as e:
    print(f"::error file={cfg_path}::Invalid JSON in pattern config: {e}")
    sys.exit(1)

url_patterns = [re.compile(p) for p in cfg.get("url", []) if isinstance(p, str)]
path_patterns = [re.compile(p) for p in cfg.get("path", []) if isinstance(p, str)]

if not url_patterns and not path_patterns:
    print("No patterns configured; skipping.")
    sys.exit(0)

def iter_json_files():
    for root, _, files in os.walk("."):
        for name in files:
            if name.lower().endswith(".json"):
                yield pathlib.Path(root, name)

def check_patterns(obj, file_path, errors):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k == "url" and isinstance(v, str) and url_patterns:
                if not any(p.match(v) for p in url_patterns):
                    print(f"::error file={file_path}::URL '{v}' failed configured regex patterns")
                    errors.append(1)
            if k == "path" and isinstance(v, str) and path_patterns:
                if not any(p.match(v) for p in path_patterns):
                    print(f"::error file={file_path}::Path '{v}' failed configured regex patterns")
                    errors.append(1)
            check_patterns(v, file_path, errors)
    elif isinstance(obj, list):
        for item in obj:
            check_patterns(item, file_path, errors)

total_errors = []
for jf in iter_json_files():
    try:
        data = json.loads(jf.read_text(encoding="utf-8"))
    except Exception:
        continue
    check_patterns(data, jf, total_errors)

sys.exit(1 if total_errors else 0)
