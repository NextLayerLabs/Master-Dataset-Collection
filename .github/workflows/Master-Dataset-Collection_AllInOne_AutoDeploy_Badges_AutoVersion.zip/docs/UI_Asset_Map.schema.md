# UI Asset Map

Asset names, paths.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, asset_name, type, path

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `asset_name` | `string` | yes |  |
| `category` | `string` | yes |  |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `path` | `string` | yes | pattern: `^assets/` |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |
| `type` | `string` | yes | enum: sprite, sprite-sheet, sound, font, vector, 3d, shader |