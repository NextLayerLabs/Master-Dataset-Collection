# Affiliate & Commission Dataset

UTMs, payout rules.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, utm, payout_rules, cookie_window_days

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `category` | `string` | yes |  |
| `cookie_window_days` | `integer` | yes | range: 1–365 |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `payout_rules` | `object` | yes |  |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |
| `utm` | `object` | yes |  |