# Marketing Assets Dataset

Flyers, captions, ad copy.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, audience, channel, flyer_copy, ad_copy

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `ad_copy` | `object` | yes |  |
| `audience` | `string` | yes |  |
| `category` | `string` | yes |  |
| `channel` | `string` | yes | enum: facebook, instagram, tiktok, print, email, google |
| `flyer_copy` | `string` | yes |  |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |