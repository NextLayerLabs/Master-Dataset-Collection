# Song Transition Rules Dataset

BPM and transitions.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, from_bpm, to_bpm, transition_type

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `category` | `string` | yes |  |
| `from_bpm` | `integer` | yes | range: 40–220 |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |
| `to_bpm` | `integer` | yes | range: 40–220 |
| `transition_type` | `string` | yes | enum: crossfade, echo-out, filter-sweep, drop-cut, beatmatch, tempo-sync |