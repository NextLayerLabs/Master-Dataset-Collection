# Payout Logic Dataset

Paytables, RTP, volatility.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, rtp, volatility, paytable

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `category` | `string` | yes |  |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `paytable` | `array` | yes | items: object |
| `rtp` | `number` | yes | range: 80–100 |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |
| `volatility` | `string` | yes | enum: Low, Medium, High, Very High |