# Website Content Dataset

HTML/Markdown page copy.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, path

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `category` | `string` | yes |  |
| `html` | `string` | no |  |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `markdown` | `string` | no |  |
| `path` | `string` | yes | pattern: `^/` |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |