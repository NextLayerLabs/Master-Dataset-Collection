# Email Templates Dataset

Automated campaigns.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, subject

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `body_html` | `string` | no |  |
| `body_text` | `string` | no |  |
| `category` | `string` | yes |  |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `subject` | `string` | yes |  |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |