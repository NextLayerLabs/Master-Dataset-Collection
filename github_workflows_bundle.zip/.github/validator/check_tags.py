#!/usr/bin/env python3
"""
Validates that any JSON files with a top-level "tags" array of strings
only use values found in .github/validator/tag_vocabulary.txt.
If the vocabulary file is missing, this script exits successfully.
"""
import os, sys, json, pathlib

vocab_file = pathlib.Path(".github/validator/tag_vocabulary.txt")
if not vocab_file.exists():
    print("No tag_vocabulary.txt found; skipping tag validation.")
    sys.exit(0)

allowed = set(t.strip() for t in vocab_file.read_text(encoding="utf-8").splitlines() if t.strip() and not t.strip().startswith("#"))
if not allowed:
    print("Vocabulary file is empty; skipping tag validation.")
    sys.exit(0)

def iter_json_files():
    for root, _, files in os.walk("."):
        for name in files:
            if name.lower().endswith(".json"):
                yield pathlib.Path(root, name)

errors = 0
for jf in iter_json_files():
    try:
        data = json.loads(jf.read_text(encoding="utf-8"))
    except Exception as e:
        # JSON syntax checked elsewhere
        continue
    tags = data.get("tags")
    if isinstance(tags, list):
        for t in tags:
            if isinstance(t, str) and t not in allowed:
                print(f"::error file={jf}::Tag '{t}' not in allowed vocabulary")
                errors += 1

if errors:
    sys.exit(1)
print("Tag vocabulary validation passed.")
