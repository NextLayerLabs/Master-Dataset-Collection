# National Resource Dataset

Venue/contact directory.

- **Minimum entries**: 200
- **Required fields**: id, category, tags, last_updated, venue_name, city, state, capacity

## Field Reference
| Field | Type | Required | Notes |
|---|---|---|---|
| `capacity` | `integer` | yes | range: 10–50000 |
| `category` | `string` | yes |  |
| `city` | `string` | yes |  |
| `id` | `string` | yes |  |
| `last_updated` | `string` | yes | pattern: `^\d{4}-\d{2}-\d{2}$` |
| `state` | `string` | yes | enum: AL, AK, AZ, AR, CA, CO, CT, DE, FL, GA, HI, ID, IL, IN, IA, KS, KY, LA, ME, MD, MA, MI, MN, MS, MO, MT, NE, NV, NH, NJ, NM, NY, NC, ND, OH, OK, OR, PA, RI, SC, SD, TN, TX, UT, VT, VA, WA, WV, WI, WY, DC |
| `tags` | `array` | yes | items: ['string', 'number', 'boolean', 'object', 'array'] |
| `venue_name` | `string` | yes |  |